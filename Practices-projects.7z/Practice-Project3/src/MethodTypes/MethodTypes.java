package MethodTypes;

public class MethodTypes {

    public static void simplemethods() {
        System.out.println("\nExecuting this simple call method...");
    }

    public static int addition(int a, int b) {
        return a + b;
    }

    public static void concat(String name) {
        System.out.println("Hi, " + name);
    }

public static void main(String args[]) {
     	// 1. Calling  method with no parameters and no return value
        simplemethods();
     
        // 2. Calling  method with parameters and a return value
        int sum = addition(5, 5);
        System.out.println("Sum of two numbers: " + sum);
        
        // 3. Calling  method with  parameter and no return value 
        concat("Your name:)");

        // 4. Storing method reference in variable and calling it
        Runnable runnable = MethodTypes::simplemethods;
        runnable.run();
        
        // 5. Calling static method using class name
        int result = MethodTypes.addition(10, 10);
        System.out.println("Sum of two numbers: " + result);
        
        // 6. Using object instance to call method
        new MethodTypes();
        MethodTypes.concat("Your name:)");

        
}
}