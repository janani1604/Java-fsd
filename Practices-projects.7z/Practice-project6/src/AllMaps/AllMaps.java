package AllMaps;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class AllMaps {
	public static void main(String args[]) {
		//hash map
		HashMap<String,Integer> hashmap=new HashMap<>();
		
		//Adding key value map pairs
		hashmap.put("hyundai",2021);
		hashmap.put("tata",2022);
		hashmap.put("honda",2023);
		
		//display key value pairs of hash map
		System.out.print("\ndisplay hash key value pairs: ");
		for (Map.Entry<String,Integer>entry : hashmap.entrySet()) {
			System.out.println(entry.getKey()+ " key -> values are " + entry.getValue() );
		}
		
		//tree map 
		TreeMap<String,Integer> treemap=new TreeMap<>();
		
		treemap.put("pulsar",2024);
		treemap.put("splendar",2025);
		treemap.put("hero", 2026);
		
		//Display key value pairs 
		System.out.println("\nTree map key and values: ");
		for(Map.Entry<String, Integer> entry : treemap.entrySet()) {
			System.out.println(entry.getKey() + "key-> values are "+ entry.getValue());
		}
		
		
		
	}
	

}
