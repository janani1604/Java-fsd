package ArrayExample;

public class ArrayExample {
	public static void main(String args[]) {
		
		int[] num= {1,2,3,4,5};
		
		System.out.println("Element of the array : ");
		for(int i=0;i < num.length; i++) {
			System.out.print(num[i] + " ");
		}
		
		System.out.println("\nElement at index 2: "+ num[2]);
		
		num[2]=10;
		
		System.out.println("\nModified arrays : ");
		for(int number:num) {
			System.out.print(number + " ");
		}
		
		int sum=0;
		for(int number:num) {
			sum +=number;
		}
			
		System.out.println("\nSum of arrays : " + sum);
		
		//string array
		String[] car= {"honda","tata","Hyundai"};
		
		System.out.println("\ncars in array: ");
		for (String cars: car) {
			System.out.print(cars + " ");
		}
		
	}

}
