package StringConversion;

public class StringConversion {
	public static void main(String args[]) {
		
		String orginalString="Hello";
		
		StringBuffer stringBuffer= new StringBuffer(orginalString);
		
		StringBuilder stringBuilder = new StringBuilder(orginalString);
		
		System.out.println("Original string: "+ orginalString);
		System.out.println("Converted to StringBuffer: "+ stringBuffer );
		System.out.println("Converted to StringBuilder: "+ stringBuilder);
		
	}

}
