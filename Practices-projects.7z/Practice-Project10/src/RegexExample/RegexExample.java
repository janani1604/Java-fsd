package RegexExample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample {
	public static void main(String[] args) {
		verifyString("HelloWorld");
		verifyString("123");
		verifyString("hello123");
		verifyString("Special@Char");
	}

	private static void verifyString(String input) {
		
		String letteronly="^[a-zA-Z]+$";
		
		Pattern pattern=Pattern.compile(letteronly);
		
		Matcher match=pattern.matcher(input);
		
		if(match.matches()) {
			System.out.println(input + " Contains only letter");
		}else {
			System.out.println(input + " not contains only letter");
		}
	}
}
