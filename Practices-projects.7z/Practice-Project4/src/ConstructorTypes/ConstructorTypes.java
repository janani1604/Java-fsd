package ConstructorTypes;

class car{
    private String make;
    private String model;
    private int year;
    
    //Default constructor
    public car() {
    	this.make="Hyundai";
    	this.model="i20";
    	this.year=2008;
    }
    
    //parameter constructor
    public car(String make,String model,int year) {
    	this.make=make;
    	this.model=model;
    	this.year=year;
    }
    
    //copy constructor
    public car(car extracar) {
    	this.make=extracar.make;
    	this.model=extracar.model;
    	this.year=extracar.year;
    }
    
    //getter method
    public String getmake() {
    	return make;
    }
    public String getmodel() {
    	return model;
    }
    public int getyear() {
    	return year;
    }
    
    //Display Method
    public void carinfo() {
    	System.out.println("Car make: " + make);
    	System.out.println("Car model: " + model);
    	System.out.println("Car year: " + year);
    }
}

public class ConstructorTypes {
       public static void main(String args[]) {
    	   //create object using default constructor
    	   car defaultcar= new car();
    	   System.out.println("\nDefault Constructor:");
    	   defaultcar.carinfo();
    	   
    	   //create object using parameter constructor
    	   car parameter=new car("toyota","camry",2022);
    	   System.out.println("\nParameter constructor");
    	   parameter.carinfo();
    	   
    	   //create object using copy constructor
    	   car originalcar=new car("Honda","Accord",2021);
    	   car copiedcar=new car(originalcar);
    	   System.out.println("\nCopy from the original car constuctor");
    	   copiedcar.carinfo();
    	   
    	   
       }
}
