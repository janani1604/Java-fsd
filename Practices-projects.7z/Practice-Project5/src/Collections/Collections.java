package Collections;

import java.util.ArrayList;
import java.util.List;


public class Collections {
	public static void main(String args[]) {
		//array list
		List<String> stringlist=new ArrayList<>();
		
		//adding elements to array list
		stringlist.add("Honda");
		stringlist.add("tata");
		stringlist.add("Hyundai");
		
		//display elements for array list
		System.out.println("\nArrayList of elements: ");
		for(String car:stringlist) {
			System.out.println(car);
		}

	}

}
