package InnerClassout;

public class InnerClassout{
	private int outerfield=10;
	
	//static inner class
	static class StaticInnerClass{
		void display() {
			System.out.println("Inside static inner class");
			//System.out.println("outer field from static inner class: " + outerfield)
		}
	}
	
	//Non-static inner class
	class InnerClass{
		void display() {
			System.out.println("Inside non-static inner class");
			System.out.println("Outer filed from non static inner class: " + outerfield);
		}
	}
	public static void main(String args[]) {
		
		//create instance of outer class
		InnerClassout outerobject= new InnerClassout();
		
		//create instance of the static inner class 
		InnerClassout.StaticInnerClass StaticInnerObject=new InnerClassout.StaticInnerClass();
		StaticInnerObject.display();
		
		//create instance of the non-static inner class
		InnerClassout.InnerClass innerObject = outerobject.new InnerClass();
		innerObject.display();
		
	}
}