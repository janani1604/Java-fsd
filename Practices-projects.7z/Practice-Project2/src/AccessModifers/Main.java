package AccessModifers;

public class Main {

	public static void main(String args[]) {
		AccessModifiers call=new AccessModifiers();
		
		System.out.println("Accessing variables from outside the class");
		System.out.println("public variable= "+ call.publicvariable);
		System.out.println("protected variable= "+ call.protectedvariable);
		//Cannot access the private in accessmodifiers 
		//System.out.println("private variable= "+ call.privatevariable);
		System.out.println("default variable= "+ call.defaultvariable);
	}
}
