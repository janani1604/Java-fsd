package AccessModifers;

public class AccessModifiers {
	
	public int publicvariable=10;
	protected int protectedvariable=20;
	private int privatevariable=30;
	int defaultvariable=40;
	
}
