package Typecasting;

public class Typecasting {

	public static void main(String[] args) {
		int intvalue=10;
		double doublevalue=intvalue;
		
		System.out.println("Implicit type casting/widening:");
		System.out.println("int value= "+intvalue);
		System.out.println("double value = "+doublevalue);
		
		double seconddoublevalue=20.5;
		int secondintvalue=(int)seconddoublevalue;
		
		System.out.println("\nExplicit type casting/narrowing:");
		System.out.println("double value= "+ seconddoublevalue);
		System.out.println("int value= "+ secondintvalue);

	}

}
