package CircularLinkedList;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    public void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (newData < head.data) {
            Node last = getLastNode();
            newNode.next = head;
            last.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }

            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void printList() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    private Node getLastNode() {
        Node last = head;
        while (last.next != head) {
            last = last.next;
        }
        return last;
    }
}

public class CircularLinkedList {
    public static void main(String[] args) {
        SortedCircularLinkedList circularList = new SortedCircularLinkedList();

        circularList.insert(3);
        circularList.insert(7);
        circularList.insert(10);
        circularList.insert(14);

        System.out.println("Original Sorted Circular Linked List:");
        circularList.printList();

        int newDataToInsert = 8;
        circularList.insert(newDataToInsert);

        System.out.println("Sorted Circular Linked List after inserting " + newDataToInsert + ":");
        circularList.printList();
    }
}
