package FourthSmallestElement;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {16, 3, 6, 8, 9, 1, 15, 6, 10, 10};
        
        int fourthSmallest = findFourthSmallestElement(unsortedList);
        
        System.out.println("fourth smallest element is: " + fourthSmallest);
    }

    static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            System.out.println("list has less than four elements.");
            return -1; 
        }

  
        Arrays.sort(arr);

        
        return arr[3];
    }
}

