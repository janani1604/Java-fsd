package StackExample;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        stack.push(5);
        stack.push(10);
        stack.push(15);

        System.out.println("Stack after pushing elements: " + stack);

        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        System.out.println("Stack after popping element: " + stack);

        stack.push(20);
        System.out.println("Stack after pushing another element: " + stack);
    }
}

