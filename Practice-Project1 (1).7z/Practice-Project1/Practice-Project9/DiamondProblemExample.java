interface Animal {
    void sound();
}

interface Carnivore extends Animal {
    default void sound() {
        System.out.println("Carnivore makes a sound");
    }
}

interface Herbivore extends Animal {
    default void sound() {
        System.out.println("Herbivore makes a sound");
    }
}

class Omnivore implements Carnivore, Herbivore {
   
    public void sound() {
        Carnivore.super.sound();
    }
}

public class DiamondProblemExample {
    public static void main(String[] args) {
        Omnivore omnivore = new Omnivore();
        omnivore.sound();
    }
}
