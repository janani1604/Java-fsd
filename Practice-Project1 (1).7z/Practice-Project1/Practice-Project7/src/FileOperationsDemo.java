import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FileOperationsDemo{

    public static void main(String[] args) {
       
        String filePath = "example.txt";

      
        createFile(filePath);

      
        readFile(filePath);

        
        updateFile(filePath, "Updated content");

       
        readFile(filePath);

       
        deleteFile(filePath);
    }

 
    private static void createFile(String filePath) {
        try {
            String content = "Hello, this is a sample content.";
            Files.write(Paths.get(filePath), content.getBytes());
            System.out.println("File created successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Read the content of a file
    private static void readFile(String filePath) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            System.out.println("File content:");
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

   
    private static void updateFile(String filePath, String newContent) {
        try {
            Files.write(Paths.get(filePath), newContent.getBytes());
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

   
    private static void deleteFile(String filePath) {
        try {
            Files.deleteIfExists(Paths.get(filePath));
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
